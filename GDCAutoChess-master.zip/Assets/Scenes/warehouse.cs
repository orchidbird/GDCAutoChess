﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class warehouse : MonoBehaviour
{
    public GameObject Warehouse;
}
